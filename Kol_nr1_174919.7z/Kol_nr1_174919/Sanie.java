import java.util.ArrayList;
import java.util.Objects;

public class Sanie {
    ArrayList<Renifer> listaReniferow;

    public Sanie(ArrayList<Renifer> listaReniferow)
    {
        this.listaReniferow=listaReniferow;
    }

    public void dodajRenifera(Renifer renifer)
    {
        listaReniferow.add(renifer);
    }

    public void sumaPredkosci()
    {
        int suma=0;
        for(int i=0;i<listaReniferow.size();i++)
        {
            suma+=listaReniferow.get(i).getPredkosc();
        }
        System.out.println(suma);
    }

    public Renifer najwolniejszyRenifer()
    {
        Renifer renifer = listaReniferow.get(0);
        for(int i=0;i<listaReniferow.size();i++)
        {
            if(listaReniferow.get(i).getPredkosc()<renifer.getPredkosc())
            {
                renifer = listaReniferow.get(i);
            }
        }
        return renifer;
    }

    public ArrayList<Renifer> getListaReniferow()
    {
        return listaReniferow;
    }

    public void setListaReniferow(ArrayList<Renifer> listaReniferow)
    {
        this.listaReniferow=listaReniferow;
    }


    @Override
    public int hashCode()
    {
        return Objects.hash(listaReniferow);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Sanie that = (Sanie) obj;
        return Objects.equals(listaReniferow, that.listaReniferow);
    }

    @Override
    public String toString()
    {
        String x ="";
        for(int i=0; i<listaReniferow.size();i++)
        {
            x+=" "+ listaReniferow.get(i).getImie();
        }
        return x;
    }


}

