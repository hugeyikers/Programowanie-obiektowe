import java.util.Objects;

public class Elf {
    private String imie;
    private int wiek;
    private String stanowisko;

    public Elf(String imie, int wiek, String stanowisko)
    {
        this.imie=imie;
        this.wiek=wiek;
        this.stanowisko=stanowisko;
    }

    public void przedstawSie()
    {
        System.out.println("Cześć, nazywam się "+ imie +", mam " + wiek + " lat, a moje stanowisko pracy to "+ stanowisko + ".");
    }

    public String getImie()
    {
        return imie;
    }

    public int getWiek()
    {
        if(wiek<=0)
        {
            throw new IllegalArgumentException("Wiek nie może być ujemny");
        }
        else this.wiek=wiek;
        return wiek;
    }

    public String getStanowisko()
    {
        return stanowisko;
    }

    public void setImie(String imie)
    {
        this.imie=imie;
    }

    public void setWiek(int wiek)
    {
        this.imie=imie;
    }

    public void setStanowisko(String stanowisko)
    {
        this.stanowisko=stanowisko;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(imie,wiek,stanowisko);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Elf that = (Elf) obj;
        return Objects.equals(imie, that.imie) && Objects.equals(wiek, that.wiek) && Objects.equals(stanowisko, that.stanowisko);
    }

    @Override
    public String toString()
    {
        return "Nazwa: " + imie + " Wiek: " + wiek + " Stanowisko: " + stanowisko;
    }
}
