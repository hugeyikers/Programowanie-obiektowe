import java.util.ArrayList;
import java.util.Objects;

public class Fabryka {
    private ArrayList<Elf> listaElfow;
    private double dlGeo;
    private double szGeo;

    public Fabryka(ArrayList<Elf> listaElfow, double dlGeo, double szGeo)
    {
        this.listaElfow=listaElfow;
        this.dlGeo = dlGeo;
        this.szGeo = szGeo;
    }

    public void dodajPracownika(Elf elf)
    {
        listaElfow.add(elf);
    }

    public void usunPracownika(Elf elf)
    {
        listaElfow.remove(elf);
    }

    public Elf najstarszyPracownik()
    {
        Elf elf = listaElfow.get(0);
        for(int i=0; i<listaElfow.size();i++)
        {
            if(listaElfow.get(i).getWiek()>elf.getWiek())
            {
                elf=listaElfow.get(i);
            }
        }
        return elf;
    }

    public ArrayList<Elf> getListaElfow()
    {
        return listaElfow;
    }

    public double getDlGeo()
    {
        return dlGeo;
    }

    public double getSzGeo()
    {
        return szGeo;
    }

    public void setListaElfow(ArrayList<Elf> listaElfow)
    {
        this.listaElfow=listaElfow;
    }

    public void setDlGeo(double dlGeo)
    {
        if(dlGeo<-180 && dlGeo>180)
        {
            throw new IllegalArgumentException("Niepoprawna wartość");
        }
        else
        {
            this.dlGeo=dlGeo;
        }
    }

    public void setSzGeo(double szGeo)
    {
        if(szGeo<-90 && szGeo>90)
        {
            throw new IllegalArgumentException("Niepoprawna wartość");
        }
        else
        {
            this.szGeo=szGeo;
        }
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(listaElfow,dlGeo,szGeo);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Fabryka that = (Fabryka) obj;
        return Objects.equals(listaElfow, that.listaElfow) && Objects.equals(dlGeo, that.dlGeo) && Objects.equals(szGeo, that.szGeo);
    }

    @Override
    public String toString()
    {
        String x ="";
        for(int i=0; i<listaElfow.size();i++)
        {
            x+=" "+ listaElfow.get(i).getImie();
        }
        return x;
    }

}
