import java.util.Objects;

public class Renifer {
    private String imie;
    private int predkosc;

    public Renifer(String imie, int predkosc)
    {
        this.imie=imie;
        this.predkosc=predkosc;
    }

    public void nakarmRenifera()
    {
        predkosc+=5;
    }

    public String getImie()
    {
        return imie;
    }

    public int getPredkosc()
    {
        return predkosc;
    }

    public void setImie(String imie)
    {
        this.imie=imie;
    }

    public void setPredkosc(int predkosc)
    {
        this.predkosc=predkosc;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(imie,predkosc);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Renifer that = (Renifer) obj;
        return Objects.equals(imie, that.imie) && Objects.equals(predkosc, that.predkosc);
    }

    @Override
    public String toString()
    {
        return "Imie: " + imie + " Prędkość: " + predkosc;
    }
}
