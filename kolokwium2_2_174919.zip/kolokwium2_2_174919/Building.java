public class Building {
    int height;
    String color;

    public Building(int height, String color)
    {
        this.height=height;
        this.color=color;
    }
}
