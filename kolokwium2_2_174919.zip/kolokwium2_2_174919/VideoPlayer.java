public class VideoPlayer implements MediaPlayer{
    String video;

    public VideoPlayer()
    {
        this.video = "";
    }

    @Override
    public void play(String trackName)
    {
        System.out.println("Playing: " + trackName);
        this.video =trackName;
    }

    @Override
    public void pause()
    {
        System.out.println("Pauza");
    }

    @Override
    public String getCurrentTrack()
    {
        return video;
    }
}
