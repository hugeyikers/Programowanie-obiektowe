public class Bitmap extends ComputerGraphic{
    @Override
    public void loadFile()
    {
        System.out.println("Ładuję Bitmapę");
    }

    @Override
    public void saveFile()
    {
        System.out.println("Zapisuję Bitmapę");
    }
}
