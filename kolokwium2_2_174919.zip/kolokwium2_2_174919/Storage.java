import java.util.ArrayList;

public class Storage<T>{
    ArrayList<T> storage;

    public Storage()
    {
        this.storage = new ArrayList<>();
    }

    public void store(T item)
    {
        if(storage.size()==0)
        {
            storage.add(item);
        }
        else if(storage.size()>=1)
        {
            System.out.println("Storage jest pełny");
        }
    }

    public T retrieve()
    {
        T item = storage.get(0);
        storage.remove(0);
        return item;
    }
}
