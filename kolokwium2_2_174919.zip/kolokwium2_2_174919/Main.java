public class Main {
    public static void main(String[] args) {

        System.out.println("Zadanie 1");
        System.out.println();

        House dom = new House(20, "czerwony", 5);
        System.out.println("Wysokość: " + dom.height + " Kolor: " + dom.color
        + " Ilość pokoi: "+ dom.numberOfRooms);

        System.out.println();
        System.out.println("Zadanie 2");
        System.out.println();

        Bitmap bitmap = new Bitmap();
        bitmap.loadFile();
        bitmap.saveFile();

        Vector vector = new Vector();
        vector.loadFile();
        vector.saveFile();

        System.out.println();
        System.out.println("Zadanie 3");
        System.out.println();

        AudioPlayer audioPlayer = new AudioPlayer();
        audioPlayer.play("Michael Jackson");
        audioPlayer.pause();
        System.out.println(audioPlayer.getCurrentTrack());

        VideoPlayer videoPlayer = new VideoPlayer();
        videoPlayer.play("From");
        videoPlayer.pause();
        System.out.println(videoPlayer.getCurrentTrack());

        System.out.println();
        System.out.println("Zadanie 4");
        System.out.println();

        Storage storage = new Storage();
        storage.store(1);
        System.out.println(storage.retrieve());

        System.out.println();
        System.out.println("Zadanie 5");
        System.out.println();

        UserAuthentication user = new UserAuthentication("Ania", "asd");
        user.login("Ania", "asd");
        user.login("Abc", "qwe");
        user.resetPassword("Ania", "asd", "qwe");
        user.logout();
        System.out.println();
        AdminAuthentication admin = new AdminAuthentication("Andrzej", "abc");
        admin.login("Andrzej", "abc");
        admin.resetPassword("Andrzej", "abc", "def");
        admin.logout();

    }
}