public class AudioPlayer implements MediaPlayer{

    String track;

    public AudioPlayer()
    {
        this.track = "";
    }

    @Override
    public void play(String trackName)
    {
        System.out.println("Playing: " + trackName);
        this.track=trackName;
    }

    @Override
    public void pause()
    {
        System.out.println("Pauza");
    }

    @Override
    public String getCurrentTrack()
    {
        return track;
    }
}
