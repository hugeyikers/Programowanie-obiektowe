public class UserAuthentication implements Authentication{

    String username;
    String password;
    public UserAuthentication(String username, String password)
    {
        this.username=username;
        this.password=password;
    }

    @Override
    public boolean login(String username, String password)
    {
        if(this.username.equals(username) && this.password.equals(password))
        {
            System.out.println("Zalogowano");
            return true;
        }
        else
        {
            System.out.println("Podane dane są nieprawidłowe");
            return false;
        }
    }

    @Override
    public void logout()
    {
        this.username=null;
        this.password=null;
        System.out.println("Wylogowano");
    }

    @Override
    public boolean resetPassword(String username, String oldPassword, String newPassword)
    {
        if(this.username.equals(username) && this.password.equals(password))
        {
            this.password = newPassword;
            System.out.println("Stare hasło zostało zmienione");
            return true;
        }
        else
        {
            System.out.println("Dane są nieprawidłowe");
            return false;
        }
    }
}
